# GFX Booster

A safe Android gaming utility/launcher starter project.

## What it does

- Performance profile inside the app
- Keeps the screen awake
- Opens Android display/refresh-rate settings
- Opens Android battery settings
- Launches an installed game by package name
- Builds from GitHub Codespaces
- GitHub Actions builds a debug APK automatically

## Important limitation

A normal third-party Android app cannot directly overclock the GPU, change kernel GPU governors, or force another game's internal FPS/GFX settings without privileged/root/OEM-specific access. This project deliberately stays within normal Android app permissions.

## Codespaces build

```bash
sudo apt-get update
sudo apt-get install -y unzip
chmod +x gradlew
./gradlew assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install with ADB when a device is connected:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions

Push the project to GitHub. The workflow at:

```text
.github/workflows/android.yml
```

builds the APK and publishes it as a workflow artifact.

## Finding a game's package name

On a device with ADB:

```bash
adb shell pm list packages | grep -i game
```

Example:

```bash
adb shell pm list packages | grep -i pubg
```

Then paste the package name into the app.

## Next upgrades

Possible additions:

- Installed-game auto detection
- Per-game profiles
- FPS overlay using a foreground service
- CPU/RAM/battery telemetry
- Game launch history
- Material/Jetpack Compose UI
- Device-specific refresh-rate guidance
- OEM-specific integrations where officially supported
