#!/usr/bin/env bash
set -euo pipefail

GRADLE_VERSION="8.9"

curl -L -o /tmp/gradle.zip \
  "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"

rm -rf /tmp/gradle-dist
mkdir -p /tmp/gradle-dist
unzip -q /tmp/gradle.zip -d /tmp/gradle-dist

export PATH="/tmp/gradle-dist/gradle-${GRADLE_VERSION}/bin:$PATH"

gradle wrapper --gradle-version "$GRADLE_VERSION"
echo "Gradle wrapper generated. You can now run: ./gradlew assembleDebug"
