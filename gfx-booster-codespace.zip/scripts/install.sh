#!/usr/bin/env bash
set -euo pipefail

APK="app/build/outputs/apk/debug/app-debug.apk"

if [ ! -f "$APK" ]; then
  echo "APK not found. Build it first."
  exit 1
fi

adb install -r "$APK"
echo "GFX Booster installed."
