#!/usr/bin/env bash
set -euo pipefail

if command -v gradle >/dev/null 2>&1; then
  gradle clean assembleDebug
else
  echo "Gradle is not installed. Run scripts/bootstrap-gradle-wrapper.sh first."
  exit 1
fi

echo
echo "APK created at:"
echo "app/build/outputs/apk/debug/app-debug.apk"
