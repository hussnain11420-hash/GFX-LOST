package com.example.gfxbooster

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var profileText: TextView
    private var performanceEnabled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        profileText = findViewById(R.id.profileText)

        findViewById<Button>(R.id.toggleProfile).setOnClickListener {
            performanceEnabled = !performanceEnabled

            if (performanceEnabled) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                profileText.text = "Performance profile active: screen awake + game launcher mode."
                statusText.text = "Performance profile ON"
                toast("Performance profile enabled")
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                profileText.text = "Balanced"
                statusText.text = "Ready"
                toast("Performance profile disabled")
            }
        }

        findViewById<Button>(R.id.keepScreenOn).setOnClickListener {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            toast("Screen will stay awake while this app is open")
        }

        findViewById<Button>(R.id.openDisplaySettings).setOnClickListener {
            safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }

        findViewById<Button>(R.id.openBatterySettings).setOnClickListener {
            safeStart(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }

        val packageInput = findViewById<EditText>(R.id.packageName)
        findViewById<Button>(R.id.launchGame).setOnClickListener {
            val packageName = packageInput.text.toString().trim()

            if (packageName.isEmpty()) {
                toast("Enter the game's package name")
                return@setOnClickListener
            }

            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                startActivity(launchIntent)
                statusText.text = "Game launched"
            } else {
                toast("Game not installed or package name is incorrect")
            }
        }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            toast("This setting is not available on this device")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
